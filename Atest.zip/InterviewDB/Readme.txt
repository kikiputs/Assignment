Hi

I wanted to repeat the test so that I could understand how to do entity framework in VB.NET outside of MVC. 

I used the following video on VB.NET with EF to create this application: 
https://www.youtube.com/watch?v=108KOJekpxo

I used the following video for listview:
https://www.dotnetheaven.com/article/listview-control-with-multiple-column-in-vb.net

I kept it to what you had asked on Friday. There are no validations.

I don't have SSRS installed on my machine, therefore I couldn't do the report.


Thanks,

Cris Ordonez
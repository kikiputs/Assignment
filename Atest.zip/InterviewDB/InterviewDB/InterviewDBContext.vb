﻿Imports System.Data.Entity
Public Class InterviewDBContext
    Inherits DbContext

    Property MultiplicationTable As DbSet(Of MultiplicationData)

End Class

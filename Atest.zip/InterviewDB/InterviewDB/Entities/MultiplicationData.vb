﻿Public Class MultiplicationData
    Public Property Id As Integer
    Public Property Integer1 As Integer
    Public Property Integer2 As Integer
    Public Property Result As Integer

End Class

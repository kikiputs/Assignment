﻿Imports System.Data.Entity

Public Class Form1
    Public Property context As InterviewDBContext

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ListView1.Clear()

        ListView1.Columns.Add("Number1", 100)
        ListView1.Columns.Add("Number2", 100)
        ListView1.Columns.Add("Result", 100)

        context = New InterviewDBContext
        context.MultiplicationTable.Load()

        For Each m As MultiplicationData In context.MultiplicationTable.Local.ToBindingList
            Dim newItem As New ListViewItem
            newItem.SubItems(0).Text = m.Integer1.ToString
            newItem.SubItems.Add(m.Integer2.ToString)
            newItem.SubItems.Add(m.Result.ToString)
            ListView1.Items.Add(newItem)
        Next

    End Sub

    Private Sub MultiplyButton_Click(sender As Object, e As EventArgs) Handles MultiplyButton.Click
        Dim m As New MultiplicationData
        Dim number1 As Integer = CInt(TextBox1.Text)
        Dim number2 As Integer = CInt(TextBox2.Text)

        m.Integer1 = number1
        m.Integer2 = number2
        m.Result = number1 * number2
        context.MultiplicationTable.Add(m)
        context.SaveChanges()
        Result.Text = m.Result.ToString
        Form1_Load(Nothing, Nothing)
    End Sub

    Private Sub NewItem_Click(sender As Object, e As EventArgs) Handles NewItem.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        Result.Text = ""
    End Sub

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Application.Exit()
    End Sub
End Class
